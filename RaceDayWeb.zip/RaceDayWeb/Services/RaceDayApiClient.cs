﻿using System.Net.Http.Headers;
using System.Net.Http.Json;
using RaceDayWeb.Models;

namespace RaceDayWeb.Services
{
    public class RaceDayApiClient : IRaceDayApiClient
    {
        private readonly HttpClient _http;
        private readonly IHttpContextAccessor _httpContext;

        public RaceDayApiClient(HttpClient http, IHttpContextAccessor httpContext)
        {
            _http = http;
            _httpContext = httpContext;
        }

        private void AddAuthHeader()
        {
            var token = _httpContext.HttpContext?.Session.GetString("JWToken");
            if (!string.IsNullOrEmpty(token))
                _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        public async Task<AuthResponse?> LoginAsync(LoginDto dto)
        {
            var response = await _http.PostAsJsonAsync("api/auth/login", dto);
            if (!response.IsSuccessStatusCode) return null;
            return await response.Content.ReadFromJsonAsync<AuthResponse>();
        }

        public async Task<AuthResponse?> RegisterAsync(RegisterDto dto)
        {
            var response = await _http.PostAsJsonAsync("api/auth/register", dto);
            if (!response.IsSuccessStatusCode) return null;
            return await response.Content.ReadFromJsonAsync<AuthResponse>();
        }

        public async Task<List<EventDto>> GetEventsAsync()
        {
            return await _http.GetFromJsonAsync<List<EventDto>>("api/events") ?? new();
        }

        public async Task<EventDto?> GetEventByIdAsync(int id)
        {
            return await _http.GetFromJsonAsync<EventDto>($"api/events/{id}");
        }

        public async Task<bool> CreateEventAsync(EventCreateDto dto)
        {
            AddAuthHeader();
            using var content = new MultipartFormDataContent();
            content.Add(new StringContent(dto.EventName), "EventName");
            content.Add(new StringContent(dto.EventDate.ToString("yyyy-MM-dd")), "EventDate");
            content.Add(new StringContent(dto.Location), "Location");
            if (!string.IsNullOrEmpty(dto.Description))
                content.Add(new StringContent(dto.Description), "Description");

            if (dto.BannerImage != null)
            {
                var fileContent = new StreamContent(dto.BannerImage.OpenReadStream());
                fileContent.Headers.ContentType = new MediaTypeHeaderValue(dto.BannerImage.ContentType);
                content.Add(fileContent, "BannerImage", dto.BannerImage.FileName);
            }

            var response = await _http.PostAsync("api/events", content);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> EnrollAsync(int categoryId)
        {
            AddAuthHeader();
            var response = await _http.PostAsJsonAsync("api/enrollments", new { CategoryID = categoryId });
            return response.IsSuccessStatusCode;
        }

        public async Task<List<EnrollmentDto>> GetMyEnrollmentsAsync()
        {
            AddAuthHeader();
            var response = await _http.GetAsync("api/enrollments/me");
            if (!response.IsSuccessStatusCode) return new();
            return await response.Content.ReadFromJsonAsync<List<EnrollmentDto>>() ?? new();
        }
    }
}