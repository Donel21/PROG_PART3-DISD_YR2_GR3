﻿using RaceDayWeb.Models;

namespace RaceDayWeb.Services
{
    public interface IRaceDayApiClient
    {
        Task<AuthResponse?> LoginAsync(LoginDto dto);
        Task<AuthResponse?> RegisterAsync(RegisterDto dto);
        Task<List<EventDto>> GetEventsAsync();
        Task<EventDto?> GetEventByIdAsync(int id);
        Task<bool> CreateEventAsync(EventCreateDto dto);
        Task<bool> EnrollAsync(int categoryId);
        Task<List<EnrollmentDto>> GetMyEnrollmentsAsync();
    }
}