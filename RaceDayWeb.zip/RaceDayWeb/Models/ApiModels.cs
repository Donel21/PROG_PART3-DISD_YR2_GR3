﻿using Microsoft.AspNetCore.Http;

namespace RaceDayWeb.Models
{
    public class LoginDto
    {
        public string Email { get; set; } = "";
        public string Password { get; set; } = "";
    }

    public class RegisterDto
    {
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string Email { get; set; } = "";
        public string Password { get; set; } = "";
        public string Role { get; set; } = "Participant";
    }

    public class AuthResponse
    {
        public int UserID { get; set; }
        public string Email { get; set; } = "";
        public string Role { get; set; } = "";
        public string Token { get; set; } = "";
    }

    public class CategoryDto
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; } = "";
        public decimal DistanceKm { get; set; }
        public decimal EntryFee { get; set; }
    }

    public class EventDto
    {
        public int EventID { get; set; }
        public string EventName { get; set; } = "";
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = "";
        public string? Description { get; set; }
        public string? BannerImageUrl { get; set; }
        public List<CategoryDto> Categories { get; set; } = new();
    }

    public class EventCreateDto
    {
        public string EventName { get; set; } = "";
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = "";
        public string? Description { get; set; }
        public IFormFile? BannerImage { get; set; }
    }

    public class EnrollmentDto
    {
        public int EnrollmentID { get; set; }
        public int ParticipantID { get; set; }
        public int CategoryID { get; set; }
        public DateTime EnrollmentDate { get; set; }
        public string Status { get; set; } = "";
    }
}