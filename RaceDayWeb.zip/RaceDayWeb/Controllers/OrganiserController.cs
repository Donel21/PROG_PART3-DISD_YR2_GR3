﻿using Microsoft.AspNetCore.Mvc;
using RaceDayWeb.Models;
using RaceDayWeb.Services;

namespace RaceDayWeb.Controllers
{
    public class OrganiserController : Controller
    {
        private readonly IRaceDayApiClient _api;
        public OrganiserController(IRaceDayApiClient api) { _api = api; }

        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser")
                return RedirectToAction("Login", "Account");

            var events = await _api.GetEventsAsync();
            return View(events);
        }

        [HttpGet]
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser")
                return RedirectToAction("Login", "Account");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(EventCreateDto dto)
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser")
                return RedirectToAction("Login", "Account");

            if (!ModelState.IsValid) return View(dto);

            var success = await _api.CreateEventAsync(dto);
            if (!success)
            {
                ViewBag.Error = "Failed to create event. Please check the inputs.";
                return View(dto);
            }
            return RedirectToAction("Index");
        }
    }
}
