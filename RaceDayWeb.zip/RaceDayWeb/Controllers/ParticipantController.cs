﻿using Microsoft.AspNetCore.Mvc;
using RaceDayWeb.Models;
using RaceDayWeb.Services;

namespace RaceDayWeb.Controllers
{
    public class ParticipantController : Controller
    {
        private readonly IRaceDayApiClient _api;
        public ParticipantController(IRaceDayApiClient api) { _api = api; }

        public async Task<IActionResult> Index(string searchString, DateTime? eventDate)
        {
            if (HttpContext.Session.GetString("UserRole") != "Participant")
                return RedirectToAction("Login", "Account");

            var events = await _api.GetEventsAsync();

            // 1. Filter by search string (Name or Location)
            if (!string.IsNullOrEmpty(searchString))
            {
                events = events.Where(e => e.EventName.Contains(searchString, StringComparison.OrdinalIgnoreCase)
                                        || e.Location.Contains(searchString, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            // 2. Filter by Date (Ignores time of day to be forgiving)
            if (eventDate.HasValue)
            {
                events = events.Where(e => e.EventDate.Date == eventDate.Value.Date).ToList();
            }

            // Sort by date
            events = events.OrderBy(e => e.EventDate).ToList();

            ViewBag.CurrentFilter = searchString;
            ViewBag.CurrentDate = eventDate?.ToString("yyyy-MM-dd");

            return View(events);
        }

        [HttpPost]
        public async Task<IActionResult> Enroll(int categoryId)
        {
            if (HttpContext.Session.GetString("UserRole") != "Participant")
                return RedirectToAction("Login", "Account");

            var success = await _api.EnrollAsync(categoryId);

            if (success)
                TempData["SuccessMessage"] = "Successfully enrolled! Get ready to race.";
            else
                TempData["ErrorMessage"] = "Failed to enroll. You might already be enrolled.";

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> MyEnrollments()
        {
            if (HttpContext.Session.GetString("UserRole") != "Participant")
                return RedirectToAction("Login", "Account");

            var enrollments = await _api.GetMyEnrollmentsAsync();
            var allEvents = await _api.GetEventsAsync();

            var viewModel = new List<ParticipantEnrollmentViewModel>();

            foreach (var enr in enrollments)
            {
                var ev = allEvents.FirstOrDefault(e => e.Categories.Any(c => c.CategoryID == enr.CategoryID));
                var cat = ev?.Categories.FirstOrDefault(c => c.CategoryID == enr.CategoryID);

                if (ev != null && cat != null)
                {
                    viewModel.Add(new ParticipantEnrollmentViewModel
                    {
                        EventName = ev.EventName,
                        EventDate = ev.EventDate,
                        CategoryName = cat.CategoryName,
                        DistanceKm = cat.DistanceKm,
                        Status = enr.Status
                    });
                }
            }

            return View(viewModel);
        }
    }

    public class ParticipantEnrollmentViewModel
    {
        public string EventName { get; set; } = "";
        public DateTime EventDate { get; set; }
        public string CategoryName { get; set; } = "";
        public decimal DistanceKm { get; set; }
        public string Status { get; set; } = "";
    }
}