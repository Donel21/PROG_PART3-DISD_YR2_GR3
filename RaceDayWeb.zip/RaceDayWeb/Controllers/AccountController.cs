﻿using Microsoft.AspNetCore.Mvc;
using RaceDayWeb.Models;
using RaceDayWeb.Services;

namespace RaceDayWeb.Controllers
{
    public class AccountController : Controller
    {
        private readonly IRaceDayApiClient _api;
        public AccountController(IRaceDayApiClient api) { _api = api; }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(LoginDto dto)
        {
            var result = await _api.LoginAsync(dto);
            if (result == null)
            {
                ViewBag.Error = "Invalid credentials";
                return View(dto);
            }

            HttpContext.Session.SetString("JWToken", result.Token);
            HttpContext.Session.SetString("UserRole", result.Role);
            HttpContext.Session.SetString("UserEmail", result.Email);

            if (result.Role == "Organiser")
                return RedirectToAction("Index", "Organiser");

            return RedirectToAction("Index", "Participant");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(RegisterDto dto)
        {
            var result = await _api.RegisterAsync(dto);
            if (result == null)
            {
                ViewBag.Error = "Email already exists or invalid data.";
                return View(dto);
            }
            return RedirectToAction("Login");
        }
    }
}