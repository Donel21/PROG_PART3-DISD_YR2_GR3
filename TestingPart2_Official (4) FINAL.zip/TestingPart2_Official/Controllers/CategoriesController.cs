﻿
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TestingPart2_Official.Data;
using TestingPart2_Official.DTOs;
using TestingPart2_Official.Models;

namespace TestingPart2_Official.Controllers
{
    [ApiController]
    [Route("api/categories")]
    public class CategoriesController : ControllerBase
    {
        private readonly ApplicationDbContext _db;

        public CategoriesController(ApplicationDbContext db)
        {
            _db = db;
        }

        // GET: api/categories
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAll()
        {
            var categories = await _db.Categories
                .Select(c => new CategoryResponseDto
                {
                    CategoryID = c.CategoryID,
                    CategoryName = c.CategoryName,
                    DistanceKm = c.DistanceKm,
                    EntryFee = c.EntryFee
                })
                .ToListAsync();

            return Ok(categories);
        }

        // GET: api/categories/5
        [HttpGet("{id:int}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetById(int id)
        {
            var category = await _db.Categories
                .FirstOrDefaultAsync(c => c.CategoryID == id);

            if (category == null)
            {
                return NotFound(new
                {
                    message = "Category not found."
                });
            }

            var response = new CategoryResponseDto
            {
                CategoryID = category.CategoryID,
                CategoryName = category.CategoryName,
                DistanceKm = category.DistanceKm,
                EntryFee = category.EntryFee
            };

            return Ok(response);
        }

        // POST: api/categories
        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> Create(
            [FromBody] CategoryCreateDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.CategoryName))
            {
                return BadRequest(new
                {
                    message = "CategoryName is required."
                });
            }

            if (dto.EventID <= 0)
            {
                return BadRequest(new
                {
                    message = "A valid EventID is required."
                });
            }

            var existingEvent = await _db.Events
                .FirstOrDefaultAsync(e => e.EventID == dto.EventID);

            if (existingEvent == null)
            {
                return NotFound(new
                {
                    message = "Event not found."
                });
            }

            var category = new Category
            {
                CategoryName = dto.CategoryName,
                DistanceKm = dto.DistanceKm,
                EntryFee = dto.EntryFee,
                EventID = dto.EventID
            };

            _db.Categories.Add(category);

            await _db.SaveChangesAsync();

            var response = new CategoryResponseDto
            {
                CategoryID = category.CategoryID,
                CategoryName = category.CategoryName,
                DistanceKm = category.DistanceKm,
                EntryFee = category.EntryFee
            };

            return StatusCode(201, response);
        }

        // PUT: api/categories/5
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> Update(
            int id,
            [FromBody] CategoryUpdateDto dto)
        {
            var category = await _db.Categories
                .Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryID == id);

            if (category == null)
            {
                return NotFound(new
                {
                    message = "Category not found."
                });
            }

            if (string.IsNullOrWhiteSpace(dto.CategoryName))
            {
                return BadRequest(new
                {
                    message = "CategoryName is required."
                });
            }

            category.CategoryName = dto.CategoryName;
            category.DistanceKm = dto.DistanceKm;
            category.EntryFee = dto.EntryFee;

            await _db.SaveChangesAsync();

            var response = new CategoryResponseDto
            {
                CategoryID = category.CategoryID,
                CategoryName = category.CategoryName,
                DistanceKm = category.DistanceKm,
                EntryFee = category.EntryFee
            };

            return Ok(response);
        }

        // DELETE: api/categories/5
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> Delete(int id)
        {
            var category = await _db.Categories
                .FindAsync(id);

            if (category == null)
            {
                return NotFound(new
                {
                    message = "Category not found."
                });
            }

            _db.Categories.Remove(category);

            await _db.SaveChangesAsync();

            return NoContent();
        }
    }
}
