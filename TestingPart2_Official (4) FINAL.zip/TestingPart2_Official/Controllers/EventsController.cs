﻿
using System;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using TestingPart2_Official.Data;
using TestingPart2_Official.DTOs;
using TestingPart2_Official.Models;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace TestingPart2_Official.Controllers
{
    [ApiController]
    [Route("api/events")]
    public class EventsController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        private readonly IConfiguration _config;

        public EventsController(ApplicationDbContext db, IConfiguration config)
        {
            _db = db;
            _config = config;
        }

        // Get the logged-in user's ID
        private int? CurrentUserId
        {
            get
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

                if (int.TryParse(userId, out int id))
                    return id;

                return null;
            }
        }

        // GET: api/events
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAll()
        {
            var events = await _db.Events
                .Include(e => e.Categories)
                .OrderBy(e => e.EventDate)
                .Select(e => new EventResponseDto
                {
                    EventID = e.EventID,
                    OrganiserID = e.OrganiserID,
                    EventName = e.EventName,
                    EventDate = e.EventDate,
                    Location = e.Location,
                    Description = e.Description,
                    BannerImageUrl = e.BannerImageUrl,

                    Categories = e.Categories.Select(c => new CategoryDto
                    {
                        CategoryID = c.CategoryID,
                        CategoryName = c.CategoryName,
                        DistanceKm = c.DistanceKm,
                        EntryFee = c.EntryFee
                    }).ToList()
                })
                .ToListAsync();

            return Ok(events);
        }

        // GET: api/events/5
        [HttpGet("{id:int}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetById(int id)
        {
            var existing = await _db.Events
                .Include(e => e.Categories)
                .FirstOrDefaultAsync(e => e.EventID == id);

            if (existing == null)
                return NotFound(new { message = "Event not found." });

            var response = new EventResponseDto
            {
                EventID = existing.EventID,
                OrganiserID = existing.OrganiserID,
                EventName = existing.EventName,
                EventDate = existing.EventDate,
                Location = existing.Location,
                Description = existing.Description,
                BannerImageUrl = existing.BannerImageUrl,

                Categories = existing.Categories.Select(c => new CategoryDto
                {
                    CategoryID = c.CategoryID,
                    CategoryName = c.CategoryName,
                    DistanceKm = c.DistanceKm,
                    EntryFee = c.EntryFee
                }).ToList()
            };

            return Ok(response);
        }

        // POST: api/events
        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> Create([FromForm] EventCreateDto dto)
        {
            if (CurrentUserId == null)
                return Unauthorized();

            if (string.IsNullOrWhiteSpace(dto.EventName) ||
                string.IsNullOrWhiteSpace(dto.Location))
            {
                return BadRequest(new
                {
                    message = "EventName and Location are required."
                });
            }

            string? imageUrl = null;

            // Upload banner image to Azure Blob Storage
            if (dto.BannerImage != null && dto.BannerImage.Length > 0)
            {
                var connectionString =
                    _config.GetConnectionString("AzureStorage");

                if (!string.IsNullOrWhiteSpace(connectionString))
                {
                    var blobServiceClient =
                        new BlobServiceClient(connectionString);

                    var containerClient =
                        blobServiceClient.GetBlobContainerClient("event-banners");

                    await containerClient.CreateIfNotExistsAsync(
                        PublicAccessType.Blob
                    );

                    string fileName = Guid.NewGuid().ToString()
                        + Path.GetExtension(dto.BannerImage.FileName);

                    var blobClient =
                        containerClient.GetBlobClient(fileName);

                    using var stream = dto.BannerImage.OpenReadStream();

                    await blobClient.UploadAsync(stream, true);

                    imageUrl = blobClient.Uri.ToString();
                }
            }

            var newEvent = new Event
            {
                OrganiserID = CurrentUserId.Value,
                EventName = dto.EventName,
                EventDate = dto.EventDate,
                Location = dto.Location,
                Description = dto.Description,
                BannerImageUrl = imageUrl
            };

            _db.Events.Add(newEvent);

            await _db.SaveChangesAsync();

            var response = new EventResponseDto
            {
                EventID = newEvent.EventID,
                OrganiserID = newEvent.OrganiserID,
                EventName = newEvent.EventName,
                EventDate = newEvent.EventDate,
                Location = newEvent.Location,
                Description = newEvent.Description,
                BannerImageUrl = newEvent.BannerImageUrl
            };

            return StatusCode(201, response);
        }

        // PUT: api/events/5
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> Update(
            int id,
            [FromBody] EventUpdateDto dto)
        {
            if (CurrentUserId == null)
                return Unauthorized();

            var existing = await _db.Events.FindAsync(id);

            if (existing == null)
                return NotFound(new { message = "Event not found." });

            if (existing.OrganiserID != CurrentUserId.Value)
                return Forbid();

            if (string.IsNullOrWhiteSpace(dto.EventName) ||
                string.IsNullOrWhiteSpace(dto.Location))
            {
                return BadRequest(new
                {
                    message = "EventName and Location are required."
                });
            }

            existing.EventName = dto.EventName;
            existing.EventDate = dto.EventDate;
            existing.Location = dto.Location;
            existing.Description = dto.Description;

            await _db.SaveChangesAsync();

            var response = new EventResponseDto
            {
                EventID = existing.EventID,
                OrganiserID = existing.OrganiserID,
                EventName = existing.EventName,
                EventDate = existing.EventDate,
                Location = existing.Location,
                Description = existing.Description,
                BannerImageUrl = existing.BannerImageUrl
            };

            return Ok(response);
        }

        // DELETE: api/events/5
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> Delete(int id)
        {
            if (CurrentUserId == null)
                return Unauthorized();

            var existing = await _db.Events.FindAsync(id);

            if (existing == null)
                return NotFound(new { message = "Event not found." });

            if (existing.OrganiserID != CurrentUserId.Value)
                return Forbid();

            _db.Events.Remove(existing);

            await _db.SaveChangesAsync();

            return NoContent();
        }
    }
}
